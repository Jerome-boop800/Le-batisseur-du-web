---
name: make-scenarios
description: Use for anything about Make (make.com) automation scenarios via the Make MCP server — listing/explaining scenarios, creating or editing them (modules, connections, routers, iterators, error handling, subscenarios, AI agents, data stores), running/activating/debugging executions and webhooks, and when a scenario tool answers 403 or refuses a write.
---

# Make scenarios

Combined skill. Read only the file(s) that match the request; each one is self-contained.

| The request is about… | Read |
|---|---|
| Orienting in an account: organizations, teams, listing scenarios, explaining what one does, connection health, account-wide audits | [explore.md](./explore.md) |
| Creating a new scenario or editing an existing one (modules, connections, mapping, flow control, error handling, subscenarios, AI agents, data stores) | [building.md](./building.md) |
| Running a scenario, switching it on/off, reviewing or debugging executions, a webhook that receives nothing | [operations.md](./operations.md) |
| A tool answers 403, refuses a write for an unclear reason, or no tool seems to cover the request (shared conventions) | [reference.md](./reference.md) |

Requires the Make MCP server (`https://mcp.make.com/claude`) to be connected. Inside the files, mentions of `reference.md`, `explore.md`, `building.md` and `operations.md` refer to the files above.
